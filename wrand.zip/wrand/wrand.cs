using System;

class WeightedRandom {
	Random random=new Random();

	double[] weights;
	double accumulatedSum;

	public WeightedRandom(double[] w) {
		weights=new double[w.Length];
		accumulatedSum=0;
		for(int i=0;i<weights.Length;i++) {
			weights[i]=w[i];
			accumulatedSum+=w[i];
		}
	}

	public int NextIndex() {
		double r=random.NextDouble()*accumulatedSum;
		for(int i=0;i<weights.Length;i++) {
			if(r<weights[i]) return i;
			r-=weights[i];
		}
		return 0;
	}
}

class Program {
	public static void Main() {
		string[] items={"Skin","Dust","Item","Rare Item",
								"Epic Item","Legendary Item"};

		double[] weights={ 20.00, 30.00, 40.00, 6.00, 3.00, 1.00};

		int[] numAppeared=new int[weights.Length];
		double percent;
		double totalPercent=0;
		int totalNumAppeared=0;
		double totalWeight=0;

		WeightedRandom weightedRandom=new WeightedRandom(weights);

		for(int i=0;i<numAppeared.Length;i++) numAppeared[i]=0;

		for(int i=0;i<1000;i++) numAppeared[weightedRandom.NextIndex()]++;

		for(int i=0;i<numAppeared.Length;i++) {
			percent=numAppeared[i]/1000.0*100.0;
			totalNumAppeared+=numAppeared[i];
			totalWeight+=weights[i];
			totalPercent+=percent;
			Console.WriteLine("{0,3}: {1,-16} {2,4} {3,6:F2}% {4,6:F2}%",
					i,items[i],numAppeared[i],weights[i],percent);
		}
		Console.WriteLine("Total                 {0,4} {1,6:F2}% {2,6:F2}%",
				totalNumAppeared,totalWeight,totalPercent);
	}

}
