#include<stdio.h>
#include<stdlib.h>
#include<time.h>

double drand() {
  return rand()/(RAND_MAX+1.0);
}

typedef struct WR_Data WR_Data;

struct WR_Data {
	double *w;
	int n;
	double s;
};

WR_Data WR_Init(double *w,int n) {
	WR_Data data;
	data.w=w;
	data.n=n;
	data.s=0;
	for(int i=0;i<data.n;i++) {
		data.s+=data.w[i];
	}
	return data;
}

int WR_NextIndex(WR_Data data) {
  double r=drand()*data.s;
  for(int i=0;i<data.n;i++) {
    if(r<data.w[i]) return i;
    r-=data.w[i];
  }
}

int main(int argc,char **argv) {

  int i;
 	char *d[]={"Skin","Dust","Item","Rare Item",
								"Epic Item","Legendary Item"};

	double w[]={ 20.00, 30.00, 40.00, 6.00, 3.00, 1.00};

  int n=sizeof(w)/sizeof(*w);
  int *s=malloc(n*sizeof(*s));
	int ts=0;
  double p,tw=0,tp=0;

	WR_Data data;

  srand(time(NULL));

	data=WR_Init(w,n);

  for(i=0;i<n;i++) s[i]=0;

  for(i=0;i<1000;i++) {
    s[WR_NextIndex(data)]++;
  }

  for(i=0;i<n;i++) {
    p=(double)s[i]/1000*100;
    ts+=s[i];
    tw+=w[i];
    tp+=p;
    printf("%3i: %-16s %4i %6.2f%% %6.2f%%\n",i,d[i],s[i],w[i],p);
  }
  printf("total:                %4i %6.2f%% %6.2f%%\n",ts,tw,tp);

  return 0;
}
